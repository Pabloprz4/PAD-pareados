package com.example.ars.features.escaner

import androidx.lifecycle.ViewModelStore
import com.example.ars.ProgresoEnMemoria
import com.example.ars.features.escaner.data.repository.CatalogoRepositoryImpl
import com.example.ars.features.museos.data.repository.MuseosRepositoryImpl
import com.example.ars.features.home.data.repository.HomeRepositoryImpl
import com.example.ars.features.escaner.domain.usecase.RegistrarObraUseCase
import com.example.ars.features.museos.domain.usecase.RegistrarVisitaMuseoUseCase
import com.example.ars.di.DefaultAppContainer
import com.example.ars.features.escaner.domain.model.Obra
import com.example.ars.features.escaner.domain.model.ResultadoValidacionQr
import com.example.ars.features.escaner.domain.repository.CatalogoRepository
import com.example.ars.features.escaner.domain.usecase.InterpretarQrUseCase
import com.example.ars.features.escaner.domain.usecase.ValidarQrUseCase
import com.example.ars.features.escaner.presentation.EscanerAction
import com.example.ars.features.escaner.presentation.EscanerViewModel
import com.example.ars.features.museos.domain.model.Museo
import com.example.ars.features.museos.domain.model.ResultadoVisitaMuseo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

class EscanerViewModelTest {
    @Test
    fun activaElMuseoYPermiteRepetirLecturas() = comprobar { vm ->
        leer(vm, "ars:v1:museo:museo_001")
        assertEquals("museo_001", vm.state.value.museoActivo?.id)
        assertFalse(assertIs<ResultadoVisitaMuseo>(vm.state.value.visitaPorAbrir).yaVisitado)
        vm.onAction(EscanerAction.MuseoAbierto)
        assertNull(vm.state.value.visitaPorAbrir)
        leer(vm, "ars:v1:museo:museo_001")
        assertTrue(assertIs<ResultadoVisitaMuseo>(vm.state.value.visitaPorAbrir).yaVisitado)
        leer(vm, "ars:v1:obra:obra_001")
        val resultado = assertIs<ResultadoValidacionQr.ObraValida>(vm.state.value.resultado)
        assertEquals("Las meninas", resultado.obra.titulo)
        assertEquals("obra_001", vm.state.value.obraPorAbrir?.obraId)
        vm.onAction(EscanerAction.ObraAbierta)
        assertNull(vm.state.value.obraPorAbrir)
        leer(vm, "ars:v1:obra:obra_001")
        assertEquals(resultado, vm.state.value.resultado)
        assertTrue(vm.state.value.obraRepetida)
        assertNull(vm.state.value.obraPorAbrir)
        vm.onAction(EscanerAction.AvisoCerrado)
        assertFalse(vm.state.value.obraRepetida)
        leer(vm, "ars:v1:obra:obra_003")
        assertIs<ResultadoValidacionQr.ObraValida>(vm.state.value.resultado)
        assertEquals("museo_002", vm.state.value.museoActivo?.id)
        leer(vm, "ars:v1:museo:museo_002")
        leer(vm, "ars:v1:obra:obra_003")
        assertEquals("Guernica", assertIs<ResultadoValidacionQr.ObraValida>(vm.state.value.resultado).obra.titulo)
    }

    @Test
    fun rechazosYCancelacionConservanElMuseo() = comprobar { vm ->
        leer(vm, "ars:v1:obra:desconocida")
        assertEquals(ResultadoValidacionQr.ObraDesconocida, vm.state.value.resultado)
        assertNull(vm.state.value.museoActivo)
        leer(vm, "ars:v1:museo:museo_001")
        val museo = vm.state.value.museoActivo
        leer(vm, "ars:v1:museo:desconocido")
        assertEquals(ResultadoValidacionQr.MuseoDesconocido, vm.state.value.resultado)
        leer(vm, null)
        assertEquals(ResultadoValidacionQr.CodigoInvalido, vm.state.value.resultado)
        vm.onAction(EscanerAction.LeerQr)
        vm.onAction(EscanerAction.LecturaCancelada)
        assertFalse(vm.state.value.leyendo)
        assertEquals(museo, vm.state.value.museoActivo)
        assertEquals(ResultadoValidacionQr.CodigoInvalido, vm.state.value.resultado)
        assertFalse(vm.state.value.error)
    }

    @Test
    fun falloDelLectorPermiteReintentarSinPerderElMuseo() = comprobar { vm ->
        leer(vm, "ars:v1:museo:museo_001")
        vm.onAction(EscanerAction.LeerQr)
        vm.onAction(EscanerAction.LecturaFallida)
        assertFalse(vm.state.value.leyendo)
        assertTrue(vm.state.value.error)
        assertEquals("museo_001", vm.state.value.museoActivo?.id)
        assertNull(vm.state.value.resultado)
        leer(vm, "ars:v1:obra:obra_001")
        assertIs<ResultadoValidacionQr.ObraValida>(vm.state.value.resultado)
        assertFalse(vm.state.value.error)
    }

    @Test
    fun noValidaDosResultadosMientrasHayUnaConsultaPendiente() = runBlocking {
        withTimeout(5_000) {
            withContext(Dispatchers.Main) {
                val consulta = CompletableDeferred<Museo?>()
                var peticiones = 0
                val repository = object : CatalogoRepository {
                    override suspend fun obtenerMuseoPorId(id: String): Museo? {
                        peticiones++
                        return consulta.await()
                    }
                    override suspend fun obtenerObraPorId(id: String): Obra? = null
                    override suspend fun obtenerObras(): List<Obra> = emptyList()
                }
                val vm = crearViewModel(ValidarQrUseCase(InterpretarQrUseCase(), repository))
                val store = ViewModelStore().apply { put("escaner", vm) }
                try {
                    vm.onAction(EscanerAction.LeerQr)
                    vm.onAction(EscanerAction.QrLeido("ars:v1:museo:museo_001"))
                    vm.onAction(EscanerAction.LeerQr)
                    vm.onAction(EscanerAction.QrLeido("ars:v1:museo:museo_002"))
                    assertTrue(vm.state.value.validando)
                    assertFalse(vm.state.value.leyendo)
                    assertEquals(1, peticiones)
                    consulta.completeExceptionally(IllegalStateException("Fallo de catálogo"))
                    vm.state.first { !it.validando }
                    assertTrue(vm.state.value.error)
                    vm.onAction(EscanerAction.LeerQr)
                    assertFalse(vm.state.value.error)
                    assertTrue(vm.state.value.leyendo)
                } finally {
                    store.clear()
                }
            }
        }
    }


    @Test
    fun falloDeGuardadoNoActivaNiAbreElMuseo() = runBlocking {
        withTimeout(5_000) {
            withContext(Dispatchers.Main) {
                val progreso = ProgresoEnMemoria().apply { fallaGuardado = true }
                val vm = crearViewModel(progreso = progreso)
                val store = ViewModelStore().apply { put("escaner", vm) }
                try {
                    leer(vm, "ars:v1:museo:museo_001")
                    assertTrue(vm.state.value.error)
                    assertNull(vm.state.value.museoActivo)
                    assertNull(vm.state.value.visitaPorAbrir)
                    assertTrue(progreso.progreso.museosVisitados.isEmpty())
                    progreso.fallaGuardado = false
                    leer(vm, "ars:v1:museo:museo_001")
                    assertFalse(vm.state.value.error)
                    assertEquals(listOf("museo_001"), progreso.progreso.museosVisitados)
                } finally {
                    store.clear()
                }
            }
        }
    }

    private fun crearViewModel(
        validar: ValidarQrUseCase = DefaultAppContainer().validarQrUseCase,
        progreso: ProgresoEnMemoria = ProgresoEnMemoria()
    ) = EscanerViewModel(
        validar,
        RegistrarVisitaMuseoUseCase(progreso, HomeRepositoryImpl(), CatalogoRepositoryImpl(MuseosRepositoryImpl())),
        RegistrarObraUseCase(progreso, HomeRepositoryImpl(), CatalogoRepositoryImpl(MuseosRepositoryImpl()))
    )

    private fun comprobar(block: suspend (EscanerViewModel) -> Unit) = runBlocking {
        withTimeout(5_000) {
            withContext(Dispatchers.Main) {
                val vm = crearViewModel()
                val store = ViewModelStore().apply { put("escaner", vm) }
                try {
                    block(vm)
                } finally {
                    store.clear()
                }
            }
        }
    }

    private suspend fun leer(vm: EscanerViewModel, contenido: String?) {
        vm.onAction(EscanerAction.LeerQr)
        vm.onAction(EscanerAction.QrLeido(contenido))
        vm.state.first { !it.validando }
    }
}
