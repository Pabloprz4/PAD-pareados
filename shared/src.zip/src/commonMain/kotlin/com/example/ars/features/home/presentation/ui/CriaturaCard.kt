package com.example.ars.features.home.presentation.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ars.features.home.domain.model.Criatura
import org.jetbrains.compose.resources.painterResource
import ars.shared.generated.resources.Res
import ars.shared.generated.resources.ars_icon_image
import ars.shared.generated.resources.menina
import ars.shared.generated.resources.caballo_guernica
import ars.shared.generated.resources.reloj_dali
import ars.shared.generated.resources.jardin_delicias
import ars.shared.generated.resources.girasol
import ars.shared.generated.resources.ninfa_venus
import ars.shared.generated.resources.el_grito
import ars.shared.generated.resources.jupiter_monstruo
import ars.shared.generated.resources.noche_estrellada
import ars.shared.generated.resources.dos_manos
import ars.shared.generated.resources.monstruo_ola
import ars.shared.generated.resources.manzana_verde
import ars.shared.generated.resources.mona_lisa
import ars.shared.generated.resources.toro_guernica
import ars.shared.generated.resources.caballero

@Composable
fun CriaturaCard(
    criatura: Criatura,
    modifier: Modifier = Modifier,
    borde: BorderStroke? = null,
    etiqueta: String = "DESCUBIERTA"
) {
    val imagenCriatura = when (criatura.nombre) {
        "Menina Fantasmal" -> Res.drawable.menina
        "Caballo Guernica" -> Res.drawable.caballo_guernica
        "Reloj Derretido" -> Res.drawable.reloj_dali
        "Humanoide del Jardín" -> Res.drawable.jardin_delicias
        "Girasol Ardiente" -> Res.drawable.girasol
        "Ninfa de Venus" -> Res.drawable.ninfa_venus
        "Espectro del Grito" -> Res.drawable.el_grito
        "Saturno Devorador" -> Res.drawable.jupiter_monstruo
        "Remolino Estrellado" -> Res.drawable.noche_estrellada
        "Manos de la Creación" -> Res.drawable.dos_manos
        "Garra de Kanagawa" -> Res.drawable.monstruo_ola
        "Manzana con Traje" -> Res.drawable.manzana_verde
        "Dama de la Mona Lisa" -> Res.drawable.mona_lisa
        "Toro Guernica" -> Res.drawable.toro_guernica
        "Caballero del Paisaje" -> Res.drawable.caballero
        else -> Res.drawable.ars_icon_image
    }

    Card(
        modifier = modifier.width(230.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 5.dp
        ),
        border = borde
    ) {

        Column {

            // Zona de la ilustración
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {

                Image(
                    painter = painterResource(imagenCriatura),
                    contentDescription = criatura.nombre,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .padding(18.dp),
                    contentScale = ContentScale.Fit
                )

                Text(
                    text = etiqueta,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
                        .padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        )
                )
            }

            // Información de la criatura
            Column(
                modifier = Modifier.padding(16.dp)
            ) {

                Text(
                    text = criatura.nombre,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    minLines = 2,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = criatura.museo,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    minLines = 2,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "Criatura ARS",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
